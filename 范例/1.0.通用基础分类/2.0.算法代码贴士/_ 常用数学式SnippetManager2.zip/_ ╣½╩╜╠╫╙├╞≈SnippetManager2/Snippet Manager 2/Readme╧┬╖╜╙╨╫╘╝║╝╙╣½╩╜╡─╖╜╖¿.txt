SNIPPET MANAGER 2
-----------------

Snippet Manager 2 is a very simple tool aimed at helping MMF2-users to organise and edit small, reuseable pieces of code (it's also suitable for use with other Clickteam products).

The concept is simple. You write out an expression, and save it as a snippet. Then the next time you want to use the same expression, you can just pick it out of a list, and SM2 will make it really easy to edit just the parts that need to be edited (such as object names).
Plus, if a variable appears more than once in an expression, you'll only need to enter the new value once, and SM2 will automatically replace it throughout.



NEW TO THIS VERSION
-------------------

SM2 looks and feels very similar to the original - most of the changes are under the surface.

* Most importantly, SM2 no longer uses ini files to store snippets. Instead, all snippets are stored in a single text file, which is parsed by SM2 on startup. The new snippet format is much simpler and easier to write (the syntax is described below).

* I've also added some handy keyboard shortcuts to make editing parameters even quicker.
 


PRE-MADE FUNCTIONS
------------------

SM2 contains many pre-made functions for the most commonly performed tasks.
To use them, all you need do is edit the parameters listed - in most cases that will mean inserting either a global value/string or an object and one of its properties, as they appear in your game.

eg. Global Value A
eg. X("Active")

Shortcuts:
* Pressing "Alt + V" and "Alt + S" will insert the words "Alterable Value" and "Alterable String" respectively. You should always rename alterable and global values - I've only included this feature because renamed alterable values are not available when using qualifiers.

* Pressing "Enter" will insert the brackets and quotes needed when entering an object name, and automatically select the text that you need to edit.



CUSTOM FUNCTIONS
----------------

You can easily add new functions by editing the file "data.txt".
The syntax is very simple:

// Comment
Group\Function = {Parameter}...

Note that parameters must always be contained within curly braces.
Comments and Groups are both optional (functions will be listed in the "Unsorted" group if none is specified), and are denoted by a "//" prefix and "\" suffix respectively.

eg:
// Standard (Euclidean) distance between two points.
Distance\Euclidean = Sqr((({Xa} - {Xb}) pow 2) + (({Ya} - {Yb}) pow 2))

This describes a function called "Euclidean" that will be listed in the group "Distance".
It uses the parameters {Xa}, {Ya}, {Xb} and {Yb} - representing two sets of coordinates.
